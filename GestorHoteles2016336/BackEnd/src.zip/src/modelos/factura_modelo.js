"use strict"

var mongoose = require("mongoose");
var Schema = mongoose.Schema;

var facturaSchema = Schema({
    gerente: {type: Schema.ObjectId, ref:"usuario"},
    reservacion: {type: Schema.ObjectId, ref:"reservacion"},
    precioTotal: Number
});
 
module.exports = mongoose.model("factura", facturaSchema);