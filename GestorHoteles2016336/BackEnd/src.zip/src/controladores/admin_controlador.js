'use strict'
const bcrypt = require("bcrypt-nodejs");
const Hotel = require("../modelos/hotel_modelo");
const Habitacion = require("../modelos/habitacion_modelo");
const jwt = require("../servicios/jwt");

function agregarHotel(req,res){
    if (req.user.rol === "ROL_ADMIN"){
        var hotel = new Hotel();
        var params = req.body;

    if(params.nombre && params.direccion && params.gerente){
        hotel.nombre = params.nombre;
        hotel.direccion = params.direccion;
        hotel.gerente = params.gerente;
        hotel.habitaciones = [];

        Hotel.find({nombreHotel: hotel.nombreHotel}).exec((err, empresaEncontrada)=>{
            if(err) return res.status(500).send({mensaje: 'Error en la solicitud de hoetl'});

            if(hotelEncontrado && hotelEncontrado.length >=1){
                return res.status(200).send({mensaje:'Este hotel ya existe'});
            }else{

                hotel.save((err, hotelGuardado)=>{
                    if(err) return res.status(500).send({mensaje: 'Error al guardar el Hotel'});

                    if (hotelGuardado){
                       return res.status(200).send(hotelGuardado);
                    }else{
                       return res.status(404).send({ mensaje: 'No se ha podido registrar el Hotel'});
                    }
                })
                
            }
        })
    }
    }else{
        return res.status(404).send({ mensaje: 'No tiene permiso para realizar esta acción'});
    }
    
}

function editarHotel(req, res) {
    if (req.user.rol === "ROL_ADMIN"){
    var id = req.params.id;
    var params = req.body;
    
    Hotel.findByIdAndUpdate(id, params, { new: true }, (err, hotelActualizado) => {
        if (err) return res.status(500).send({ mensaje: 'Error en la peticion' });
        if (!hotelActualizado) return res.status(500).send({ mensaje: 'No se a podido editar el hotel' });

        return res.status(200).send({ hotelActualizado })
    })
}
  
}

function eliminarHotel(req, res){
    if (req.user.rol === "ROL_ADMIN"){
    var id = req.params.id;

    Hotel.findByIdAndDelete(id, (err, hotelEliminado) =>{
        if(err) return res.status(500).send({mensaje: "Error en la peticion"});
        if(!hotelEliminado) return res.status(500).send({mensaje:"No se ha eliminado el hotel"});

        return res.status(200).send({mensaje: "hotel Eliminado"});
    })
    }
}

function obtenerHoteles(req, res){
    Hotel.find().exec((err, hoteles)=>{
        if(err) return res.status(500).send({ mensaje:"Error al realizar la solicitud de obtener hoteles" });
        if(!hoteles) return res.status(500).send({ mensaje:"No se encontraron hoteles" });

        return res.status(200).send({ hoteles });
    })
}

function obtenerHotel(req, res) {
    var params = req.body;

    Empresa.findOne({ "nombre": params.nombre } || {"direccion": params.direccion }, (err, hotelEncontrado)=>{
        if(err) return res.status(500).send({ mensaje:"Error en la peticion" });
        if(!hotelEncontrado) return res.status(500).send({mensaje: 'Error al obtener el Empleado' });

        return res.status(200).send({ hotelEncontrado });
    })

}


//----------------------------------------------------------

function agregarHabitacion(req,res){
    if (req.user.rol === "ROL_ADMIN"){
        var habitacion = new Habitacion();
        var params = req.body;

    if(params.nombre && params.estado && params.precio && params.idHotel && params.nombreHotel){
        habitacion.nombre = params.nombre;
        habitacion.estado = params.estado;
        habitacion.precio = params.precio;
        habitacion.idHotel = params.idHotel;
        habitacion.nombreHotel = params.nombreHotel;

        Hotel.find({nombreHotel: hotel.nombreHotel}).exec((err, hotelEncontrado)=>{
            if(err) return res.status(500).send({mensaje: 'Error en la solicitud de hoetl'});

            if(hotelEncontrado && hotelEncontrado.length == 0){
                return res.status(200).send({mensaje:'Este hotel no existe'});
            }else{

                habitacion.save((err, habitacionGuardada)=>{
                    if(err) return res.status(500).send({mensaje: 'Error al guardar la habitacion'});

                    if (habitacionGuardada){
                       return res.status(200).send({habitacionGuardada});
                    }else{
                       return res.status(404).send({ mensaje: 'No se ha podido registrar la habitacion'});
                    }
                })
                
            }
        })
    }
    }else{
        return res.status(404).send({ mensaje: 'No tiene permiso para realizar esta acción'});
    }
    
}

function editarHabitacion(req, res) {
    if (req.user.rol === "ROL_ADMIN"){
    var id = req.params.id;
    var params = req.body;
    
    Hotel.findByIdAndUpdate(id, params, { new: true }, (err, habitacionActualizada) => {
        if (err) return res.status(500).send({ mensaje: 'Error en la peticion' });
        if (!habitacionActualizada) return res.status(500).send({ mensaje: 'No se a podido editar la habitacion' });

        return res.status(200).send({ habitacionActualizada })
    })
}
  
}

function eliminarHabitacion(req, res){
    if (req.user.rol === "ROL_ADMIN"){
    var id = req.params.id;

    Hotel.findByIdAndDelete(id, (err, habitacionEliminada) =>{
        if(err) return res.status(500).send({mensaje: "Error en la peticion"});
        if(!habitacionEliminada) return res.status(500).send({mensaje:"No se ha eliminado la habitacion"});

        return res.status(200).send({mensaje: "habitacion eliminada"});
    })
    }
}

function obtenerHabitaciones(req, res){
    var params = req.body;

    Hotel.find("hotel.nombre" == params.nombre).exec((err, habitaciones)=>{
        if(err) return res.status(500).send({ mensaje:"Error al realizar la solicitud de obtener habitaciones" });
        if(!habitaciones) return res.status(500).send({ mensaje:"No se encontraron habitaciones" });

        return res.status(200).send({ habitaciones });
    })
}


module.exports = {
    agregarHotel,
    editarHotel,
    eliminarHotel,
    obtenerHoteles,
    obtenerHotel,
    agregarHabitacion,
    editarHabitacion,
    eliminarHabitacion,
    obtenerHabitaciones


}
